YSANG BIRTHDAY WEBSITE — FIXED

This version is self-contained:
- The 6 PDF pictures are embedded directly in index.html.
- The uploaded "I Will (Remastered 2009)" MP3 is embedded directly in index.html.
- No image or music file path is required for the page to work.
- The pictures have NO added captions or sweet lines.
- Click "Open My Heart 💌" to start the music. Browsers require a user interaction before allowing audio.

You can simply double-click index.html, or use VS Code + Live Server.
